using Microsoft.EntityFrameworkCore;

namespace BlazorApp.Data;

public class BlazorContext : DbContext
{
    public BlazorContext(DbContextOptions options) : base(options)
    {

    }
}