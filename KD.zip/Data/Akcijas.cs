using System.ComponentModel.DataAnnotations.Schema;

namespace BlazorApp.Data;

[Table("akcijas", Schema = "public")]
public class Akcijas
{
    public int id { get; set; }
    public string nosaukums { get; set; }
    public bool akcija { get; set; }
    public string parameter_1 { get; set; }
    public string parameter_2 { get; set; }
    public string parameter_3 { get; set; }
    public string parameter_4 { get; set; }
    public string parameter_5 { get; set; }
    public string parameter_6 { get; set; }
    public string parameter_7 { get; set; }
    public float bez_akcijas { get; set; }
    public float ar_akciju { get; set; }
    public string valuta { get; set; }
    public string link_key { get; set; }

}