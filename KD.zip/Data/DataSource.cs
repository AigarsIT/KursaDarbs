using Microsoft.AspNetCore.Components;



namespace BlazorApp.Data;

public class DataSource
{
    private readonly BlazorContext context;

    public DataSource(BlazorContext context)
    {
        this.context = context;
    }

    public List<Akcijas> GetData()
    {
        return context.Akcijas.Where(x => x.akcija == true).Select(x => new Akcijas
        {
            id = x.id,
            nosaukums = x.nosaukums,
            akcija = x.akcija,
            parameter_1 = x.parameter_1,
            ar_akciju = x.ar_akciju,
            valuta = x.valuta
        }).ToList();
       
    } 


}